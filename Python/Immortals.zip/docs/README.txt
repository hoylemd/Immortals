Immortals Readme

Immortals is a Tactical combat game.  You play as an Immortal, a being of great power who can cast mighty spells and summon fearsome allies to his side.

What you need:

Python (2.7 reccomended, 32-bit version required)
Pygame

Installation instructions:
Unzip all files into a folder and run "immortal.py"

Gameplay:
You can't actually do anything yet.